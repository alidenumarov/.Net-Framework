namespace Lesson6.Models 
{
    public class Film 
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Authors { get; set; }

        public int Rating { get; set; }
    }
}