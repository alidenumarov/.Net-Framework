namespace Calc.Models 
{
    public class Calculator 
    {
        public float Operand1 { get; set; }

        public float Operand2 { get; set; }

        public string Operation { get; set; }

        public float Result { get; set; }
    }
}